# AI Marketing Reels Generator

Kinetic typography Instagram Reels — AI powered.

## DEPLOY IN 5 STEPS

### 1. Clone & Push to GitHub
```bash
git clone https://github.com/bekzodhq-arch/ai-marketing-reels.git
cd ai-marketing-reels
# Copy all project files here
git add .
git commit -m "init"
git push
```

### 2. Connect Vercel
- vercel.com → New Project
- Import: `ai-marketing-reels` from GitHub
- Framework: Other

### 3. Set Environment Variable
In Vercel dashboard → Settings → Environment Variables:
```
ANTHROPIC_API_KEY = your_key_here
```

### 4. Deploy
Vercel auto-deploys on every push.

### 5. Done
Your URL: `https://ai-marketing-reels.vercel.app`

---

## HOW IT WORKS
1. Click GENERATE
2. Claude AI creates 5 marketing term scripts
3. Gravity/weight kinetic typography renders in browser
4. Click any reel to play the animation
5. Screen record for Instagram export
